module.exports = "snowball-fixture-e";
