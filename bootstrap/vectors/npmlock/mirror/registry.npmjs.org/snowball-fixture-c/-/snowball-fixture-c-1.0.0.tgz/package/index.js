module.exports = "snowball-fixture-c";
